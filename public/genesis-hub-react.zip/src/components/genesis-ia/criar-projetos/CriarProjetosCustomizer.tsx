import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ArrowLeft, 
  Save, 
  Loader2, 
  Palette, 
  Building2, 
  Phone, 
  MapPin,
  Globe,
  Clock,
  Settings2,
  Calendar,
  Star,
  Users,
  ImageIcon,
  MessageCircle,
  Instagram,
  Facebook,
  Sparkles,
  Check,
  X,
  ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { TemplateInfo } from './CriarProjetosSelector';
import { ProjectConfig } from './CriarProjetosManager';

interface CriarProjetosCustomizerProps {
  template: TemplateInfo;
  editingConfig: ProjectConfig | null;
  affiliateId: string;
  onBack: () => void;
  onSaved: () => void;
}

interface TemplateConfigData {
  business: {
    name: string;
    phone: string;
    whatsapp: string;
    address: string;
    slogan: string;
  };
  branding: {
    primaryColor: string;
    secondaryColor: string;
    accentColor: string;
    logoUrl: string | null;
  };
  features: {
    showPricing: boolean;
    showTeam: boolean;
    showGallery: boolean;
    showScheduling: boolean;
    showTestimonials: boolean;
    showContact: boolean;
  };
  social: {
    instagram: string;
    facebook: string;
  };
  hours: {
    weekdays: string;
    saturday: string;
    sunday: string;
  };
}

const defaultConfig: TemplateConfigData = {
  business: {
    name: '',
    phone: '',
    whatsapp: '',
    address: '',
    slogan: '',
  },
  branding: {
    primaryColor: '#3b82f6',
    secondaryColor: '#1e40af',
    accentColor: '#60a5fa',
    logoUrl: null,
  },
  features: {
    showPricing: true,
    showTeam: true,
    showGallery: true,
    showScheduling: true,
    showTestimonials: true,
    showContact: true,
  },
  social: {
    instagram: '',
    facebook: '',
  },
  hours: {
    weekdays: '08:00 - 18:00',
    saturday: '09:00 - 14:00',
    sunday: 'Fechado',
  },
};

type Section = 'info' | 'branding' | 'features' | 'social' | 'link';

const sections: { id: Section; label: string; icon: React.ElementType }[] = [
  { id: 'info', label: 'Informações', icon: Building2 },
  { id: 'branding', label: 'Visual', icon: Palette },
  { id: 'features', label: 'Recursos', icon: Settings2 },
  { id: 'social', label: 'Redes & Horários', icon: Clock },
  { id: 'link', label: 'Publicar', icon: Globe },
];

export function CriarProjetosCustomizer({
  template,
  editingConfig,
  affiliateId,
  onBack,
  onSaved,
}: CriarProjetosCustomizerProps) {
  const [saving, setSaving] = useState(false);
  const [clientName, setClientName] = useState('');
  const [customSlug, setCustomSlug] = useState('');
  const [config, setConfig] = useState<TemplateConfigData>(defaultConfig);
  const [activeSection, setActiveSection] = useState<Section>('info');

  useEffect(() => {
    if (editingConfig) {
      setClientName(editingConfig.client_name || '');
      setCustomSlug(editingConfig.custom_slug || '');
      const savedConfig = editingConfig.config as unknown as TemplateConfigData;
      if (savedConfig && typeof savedConfig === 'object') {
        setConfig({
          ...defaultConfig,
          ...savedConfig,
          business: { ...defaultConfig.business, ...savedConfig.business },
          branding: { ...defaultConfig.branding, ...savedConfig.branding },
          features: { ...defaultConfig.features, ...savedConfig.features },
          social: { ...defaultConfig.social, ...savedConfig.social },
          hours: { ...defaultConfig.hours, ...savedConfig.hours },
        });
      }
    }
  }, [editingConfig]);

  const generateUniqueCode = () => {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
  };

  const handleSave = async () => {
    if (customSlug) {
      const slugPattern = /^[a-z0-9-]+$/;
      if (!slugPattern.test(customSlug)) {
        toast.error('Rota inválida', {
          description: 'Use apenas letras minúsculas, números e hífens'
        });
        return;
      }

      const { data: existing } = await supabase
        .from('affiliate_template_configs')
        .select('id')
        .eq('custom_slug', customSlug)
        .neq('id', editingConfig?.id || '')
        .maybeSingle();

      if (existing) {
        toast.error('Rota já em uso', {
          description: 'Escolha outra rota personalizada'
        });
        return;
      }
    }

    setSaving(true);

    try {
      if (editingConfig) {
        const { error } = await supabase
          .from('affiliate_template_configs')
          .update({
            client_name: clientName || null,
            custom_slug: customSlug || null,
            config: JSON.parse(JSON.stringify(config)),
            updated_at: new Date().toISOString()
          })
          .eq('id', editingConfig.id);

        if (error) throw error;
        toast.success('Projeto atualizado!');
      } else {
        const uniqueCode = generateUniqueCode();
        const { error } = await supabase
          .from('affiliate_template_configs')
          .insert([{
            affiliate_id: affiliateId,
            template_slug: template.id,
            template_name: template.name,
            unique_code: uniqueCode,
            custom_slug: customSlug || null,
            client_name: clientName || null,
            config: JSON.parse(JSON.stringify(config)),
            is_active: true
          }]);

        if (error) throw error;
        toast.success('Projeto criado!', {
          description: `Acesse: /p/${customSlug || uniqueCode}`
        });
      }

      onSaved();
    } catch (error) {
      console.error('Error saving:', error);
      toast.error('Erro ao salvar projeto');
    }

    setSaving(false);
  };

  const updateBusiness = (field: keyof typeof config.business, value: string) => {
    setConfig(prev => ({
      ...prev,
      business: { ...prev.business, [field]: value }
    }));
  };

  const updateBranding = (field: keyof typeof config.branding, value: string | null) => {
    setConfig(prev => ({
      ...prev,
      branding: { ...prev.branding, [field]: value }
    }));
  };

  const updateFeature = (field: keyof typeof config.features, value: boolean) => {
    setConfig(prev => ({
      ...prev,
      features: { ...prev.features, [field]: value }
    }));
  };

  const updateSocial = (field: keyof typeof config.social, value: string) => {
    setConfig(prev => ({
      ...prev,
      social: { ...prev.social, [field]: value }
    }));
  };

  const updateHours = (field: keyof typeof config.hours, value: string) => {
    setConfig(prev => ({
      ...prev,
      hours: { ...prev.hours, [field]: value }
    }));
  };

  const featuresList = [
    { key: 'showScheduling' as const, label: 'Agendamento Online', icon: Calendar, description: 'Permitir agendamentos' },
    { key: 'showPricing' as const, label: 'Tabela de Preços', icon: Star, description: 'Serviços e valores' },
    { key: 'showTeam' as const, label: 'Equipe', icon: Users, description: 'Membros da equipe' },
    { key: 'showGallery' as const, label: 'Galeria', icon: ImageIcon, description: 'Fotos e trabalhos' },
    { key: 'showTestimonials' as const, label: 'Depoimentos', icon: MessageCircle, description: 'Avaliações de clientes' },
    { key: 'showContact' as const, label: 'Contato', icon: Phone, description: 'Formulário de contato' },
  ];

  const currentSectionIndex = sections.findIndex(s => s.id === activeSection);
  const progress = ((currentSectionIndex + 1) / sections.length) * 100;

  return (
    <div className="space-y-4">
      {/* Modal-like Header - Same style as EvolutionWizard */}
      <div className="flex items-center justify-between p-3 rounded-t-xl bg-white/5 border border-white/10 border-b-0">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={onBack} className="h-7 w-7 rounded-full hover:bg-white/10">
            <ArrowLeft className="w-3.5 h-3.5" />
          </Button>
          <div className="w-7 h-7 rounded-lg bg-primary/20 flex items-center justify-center">
            <Sparkles className="w-3.5 h-3.5 text-primary" />
          </div>
          <div>
            <h2 className="text-sm font-semibold text-foreground">
              {editingConfig ? 'Editar' : 'Criar'} Projeto
            </h2>
            <p className="text-[10px] text-muted-foreground">{template.name}</p>
          </div>
        </div>
        <Button onClick={handleSave} disabled={saving} size="sm" className="h-7 text-[11px] px-3 gap-1.5">
          {saving ? (
            <Loader2 className="w-3 h-3 animate-spin" />
          ) : (
            <>
              <Save className="w-3 h-3" />
              Salvar
            </>
          )}
        </Button>
      </div>

      {/* Content Area - Same container style as EvolutionWizard */}
      <div className="p-4 rounded-b-xl bg-white/5 border border-white/10 border-t-0 -mt-4">
        {/* Progress Bar */}
        <div className="mb-4">
          <div className="h-1 bg-white/10 rounded-full overflow-hidden">
            <motion.div 
              className="h-full bg-primary rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>
          <p className="text-[10px] text-muted-foreground mt-1">
            Etapa {currentSectionIndex + 1} de {sections.length}
          </p>
        </div>

        {/* Section Navigation - Compact tabs */}
        <div className="flex gap-1 mb-4 overflow-x-auto pb-1 scrollbar-hide">
          {sections.map((section, index) => {
            const Icon = section.icon;
            const isActive = activeSection === section.id;
            const isCompleted = index < currentSectionIndex;
            
            return (
              <button
                key={section.id}
                onClick={() => setActiveSection(section.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-medium whitespace-nowrap transition-all ${
                  isActive 
                    ? 'bg-primary text-primary-foreground' 
                    : isCompleted 
                      ? 'bg-primary/10 text-primary' 
                      : 'bg-white/5 text-muted-foreground hover:bg-white/10'
                }`}
              >
                {isCompleted && !isActive ? (
                  <Check className="w-3 h-3" />
                ) : (
                  <Icon className="w-3 h-3" />
                )}
                {section.label}
              </button>
            );
          })}
        </div>

        {/* Content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeSection}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.15 }}
          >
            {/* Informações */}
            {activeSection === 'info' && (
              <div className="space-y-3">
                <div className="flex items-center gap-2 pb-2 border-b border-white/10">
                  <div className="w-5 h-5 rounded bg-primary/20 flex items-center justify-center">
                    <Building2 className="w-2.5 h-2.5 text-primary" />
                  </div>
                  <span className="text-[11px] font-semibold text-primary uppercase tracking-wider">
                    Dados do Negócio
                  </span>
                </div>
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="space-y-1.5 sm:col-span-2">
                    <Label className="text-[10px] uppercase tracking-wider text-muted-foreground">Nome do Negócio *</Label>
                    <Input
                      placeholder="Ex: Pet Shop Amigo Fiel"
                      value={config.business.name}
                      onChange={(e) => updateBusiness('name', e.target.value)}
                      className="h-9 bg-white/5 border-white/10 text-sm"
                    />
                  </div>
                  <div className="space-y-1.5 sm:col-span-2">
                    <Label className="text-[10px] uppercase tracking-wider text-muted-foreground">Slogan</Label>
                    <Input
                      placeholder="Ex: Cuidando com amor desde 2010"
                      value={config.business.slogan}
                      onChange={(e) => updateBusiness('slogan', e.target.value)}
                      className="h-9 bg-white/5 border-white/10 text-sm"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-[10px] uppercase tracking-wider text-muted-foreground">Telefone</Label>
                    <Input
                      placeholder="(11) 99999-9999"
                      value={config.business.phone}
                      onChange={(e) => updateBusiness('phone', e.target.value)}
                      className="h-9 bg-white/5 border-white/10 text-sm"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-[10px] uppercase tracking-wider text-muted-foreground">WhatsApp</Label>
                    <Input
                      placeholder="5511999999999"
                      value={config.business.whatsapp}
                      onChange={(e) => updateBusiness('whatsapp', e.target.value)}
                      className="h-9 bg-white/5 border-white/10 text-sm"
                    />
                  </div>
                  <div className="space-y-1.5 sm:col-span-2">
                    <Label className="text-[10px] uppercase tracking-wider text-muted-foreground">Endereço</Label>
                    <Input
                      placeholder="Rua, número - Bairro, Cidade"
                      value={config.business.address}
                      onChange={(e) => updateBusiness('address', e.target.value)}
                      className="h-9 bg-white/5 border-white/10 text-sm"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Branding */}
            {activeSection === 'branding' && (
              <div className="space-y-3">
                <div className="flex items-center gap-2 pb-2 border-b border-white/10">
                  <div className="w-5 h-5 rounded bg-primary/20 flex items-center justify-center">
                    <Palette className="w-2.5 h-2.5 text-primary" />
                  </div>
                  <span className="text-[11px] font-semibold text-primary uppercase tracking-wider">
                    Cores do Site
                  </span>
                </div>
                <div className="grid gap-3 sm:grid-cols-3">
                  <div className="space-y-1.5">
                    <Label className="text-[10px] uppercase tracking-wider text-muted-foreground">Cor Principal</Label>
                    <div className="flex gap-2">
                      <div 
                        className="w-9 h-9 rounded-lg border border-white/10 cursor-pointer overflow-hidden"
                        style={{ backgroundColor: config.branding.primaryColor }}
                      >
                        <input
                          type="color"
                          value={config.branding.primaryColor}
                          onChange={(e) => updateBranding('primaryColor', e.target.value)}
                          className="w-full h-full opacity-0 cursor-pointer"
                        />
                      </div>
                      <Input
                        value={config.branding.primaryColor}
                        onChange={(e) => updateBranding('primaryColor', e.target.value)}
                        className="flex-1 font-mono text-[10px] h-9 bg-white/5 border-white/10"
                      />
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-[10px] uppercase tracking-wider text-muted-foreground">Cor Secundária</Label>
                    <div className="flex gap-2">
                      <div 
                        className="w-9 h-9 rounded-lg border border-white/10 cursor-pointer overflow-hidden"
                        style={{ backgroundColor: config.branding.secondaryColor }}
                      >
                        <input
                          type="color"
                          value={config.branding.secondaryColor}
                          onChange={(e) => updateBranding('secondaryColor', e.target.value)}
                          className="w-full h-full opacity-0 cursor-pointer"
                        />
                      </div>
                      <Input
                        value={config.branding.secondaryColor}
                        onChange={(e) => updateBranding('secondaryColor', e.target.value)}
                        className="flex-1 font-mono text-[10px] h-9 bg-white/5 border-white/10"
                      />
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-[10px] uppercase tracking-wider text-muted-foreground">Cor de Destaque</Label>
                    <div className="flex gap-2">
                      <div 
                        className="w-9 h-9 rounded-lg border border-white/10 cursor-pointer overflow-hidden"
                        style={{ backgroundColor: config.branding.accentColor }}
                      >
                        <input
                          type="color"
                          value={config.branding.accentColor}
                          onChange={(e) => updateBranding('accentColor', e.target.value)}
                          className="w-full h-full opacity-0 cursor-pointer"
                        />
                      </div>
                      <Input
                        value={config.branding.accentColor}
                        onChange={(e) => updateBranding('accentColor', e.target.value)}
                        className="flex-1 font-mono text-[10px] h-9 bg-white/5 border-white/10"
                      />
                    </div>
                  </div>
                </div>

                {/* Preview */}
                <div className="mt-3 p-3 rounded-lg bg-white/5 border border-white/10">
                  <p className="text-[10px] text-muted-foreground mb-2 uppercase tracking-wider">Preview</p>
                  <div className="flex gap-2">
                    <div 
                      className="flex-1 h-10 rounded-lg flex items-center justify-center text-white text-[10px] font-medium"
                      style={{ backgroundColor: config.branding.primaryColor }}
                    >
                      Principal
                    </div>
                    <div 
                      className="flex-1 h-10 rounded-lg flex items-center justify-center text-white text-[10px] font-medium"
                      style={{ backgroundColor: config.branding.secondaryColor }}
                    >
                      Secundária
                    </div>
                    <div 
                      className="flex-1 h-10 rounded-lg flex items-center justify-center text-white text-[10px] font-medium"
                      style={{ backgroundColor: config.branding.accentColor }}
                    >
                      Destaque
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Features */}
            {activeSection === 'features' && (
              <div className="space-y-3">
                <div className="flex items-center gap-2 pb-2 border-b border-white/10">
                  <div className="w-5 h-5 rounded bg-primary/20 flex items-center justify-center">
                    <Settings2 className="w-2.5 h-2.5 text-primary" />
                  </div>
                  <span className="text-[11px] font-semibold text-primary uppercase tracking-wider">
                    Recursos do Site
                  </span>
                </div>
                <div className="grid gap-2">
                  {featuresList.map((feature) => {
                    const Icon = feature.icon;
                    const isEnabled = config.features[feature.key];
                    
                    return (
                      <div 
                        key={feature.key}
                        className={`flex items-center justify-between p-2.5 rounded-lg border transition-all ${
                          isEnabled ? 'bg-primary/5 border-primary/20' : 'bg-white/5 border-white/10'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${
                            isEnabled ? 'bg-primary/10 text-primary' : 'bg-white/10 text-muted-foreground'
                          }`}>
                            <Icon className="w-3.5 h-3.5" />
                          </div>
                          <div>
                            <p className="text-xs font-medium text-foreground">{feature.label}</p>
                            <p className="text-[10px] text-muted-foreground">{feature.description}</p>
                          </div>
                        </div>
                        <Switch
                          checked={isEnabled}
                          onCheckedChange={(checked) => updateFeature(feature.key, checked)}
                        />
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Social & Hours */}
            {activeSection === 'social' && (
              <div className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center gap-2 pb-2 border-b border-white/10">
                    <div className="w-5 h-5 rounded bg-primary/20 flex items-center justify-center">
                      <Globe className="w-2.5 h-2.5 text-primary" />
                    </div>
                    <span className="text-[11px] font-semibold text-primary uppercase tracking-wider">
                      Redes Sociais
                    </span>
                  </div>
                  <div className="grid gap-3 sm:grid-cols-2">
                    <div className="space-y-1.5">
                      <Label className="text-[10px] uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
                        <Instagram className="w-3 h-3" /> Instagram
                      </Label>
                      <Input
                        placeholder="@usuario"
                        value={config.social.instagram}
                        onChange={(e) => updateSocial('instagram', e.target.value)}
                        className="h-9 bg-white/5 border-white/10 text-sm"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-[10px] uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
                        <Facebook className="w-3 h-3" /> Facebook
                      </Label>
                      <Input
                        placeholder="facebook.com/pagina"
                        value={config.social.facebook}
                        onChange={(e) => updateSocial('facebook', e.target.value)}
                        className="h-9 bg-white/5 border-white/10 text-sm"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-2 pb-2 border-b border-white/10">
                    <div className="w-5 h-5 rounded bg-primary/20 flex items-center justify-center">
                      <Clock className="w-2.5 h-2.5 text-primary" />
                    </div>
                    <span className="text-[11px] font-semibold text-primary uppercase tracking-wider">
                      Horário de Funcionamento
                    </span>
                  </div>
                  <div className="grid gap-3 sm:grid-cols-3">
                    <div className="space-y-1.5">
                      <Label className="text-[10px] uppercase tracking-wider text-muted-foreground">Seg - Sex</Label>
                      <Input
                        placeholder="08:00 - 18:00"
                        value={config.hours.weekdays}
                        onChange={(e) => updateHours('weekdays', e.target.value)}
                        className="h-9 bg-white/5 border-white/10 text-sm"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-[10px] uppercase tracking-wider text-muted-foreground">Sábado</Label>
                      <Input
                        placeholder="09:00 - 14:00"
                        value={config.hours.saturday}
                        onChange={(e) => updateHours('saturday', e.target.value)}
                        className="h-9 bg-white/5 border-white/10 text-sm"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-[10px] uppercase tracking-wider text-muted-foreground">Domingo</Label>
                      <Input
                        placeholder="Fechado"
                        value={config.hours.sunday}
                        onChange={(e) => updateHours('sunday', e.target.value)}
                        className="h-9 bg-white/5 border-white/10 text-sm"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Link / Publish */}
            {activeSection === 'link' && (
              <div className="space-y-3">
                <div className="flex items-center gap-2 pb-2 border-b border-white/10">
                  <div className="w-5 h-5 rounded bg-primary/20 flex items-center justify-center">
                    <Globe className="w-2.5 h-2.5 text-primary" />
                  </div>
                  <span className="text-[11px] font-semibold text-primary uppercase tracking-wider">
                    Publicação
                  </span>
                </div>
                
                <div className="space-y-3">
                  <div className="space-y-1.5">
                    <Label className="text-[10px] uppercase tracking-wider text-muted-foreground">Nome do Cliente (opcional)</Label>
                    <Input
                      placeholder="Ex: Pet Shop do João"
                      value={clientName}
                      onChange={(e) => setClientName(e.target.value)}
                      className="h-9 bg-white/5 border-white/10 text-sm"
                    />
                    <p className="text-[10px] text-muted-foreground">
                      Este nome aparecerá na sua lista de projetos
                    </p>
                  </div>

                  <div className="space-y-1.5">
                    <Label className="text-[10px] uppercase tracking-wider text-muted-foreground">URL Personalizada (opcional)</Label>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-muted-foreground whitespace-nowrap">/p/</span>
                      <Input
                        placeholder="minha-empresa"
                        value={customSlug}
                        onChange={(e) => setCustomSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ''))}
                        className="h-9 bg-white/5 border-white/10 text-sm font-mono"
                      />
                    </div>
                    <p className="text-[10px] text-muted-foreground">
                      Use apenas letras minúsculas, números e hífens
                    </p>
                  </div>

                  {/* Preview URL */}
                  <div className="p-3 rounded-lg bg-white/5 border border-white/10">
                    <p className="text-[10px] text-muted-foreground mb-1 uppercase tracking-wider">URL do seu projeto</p>
                    <p className="text-xs font-mono text-primary break-all">
                      /p/{customSlug || '[código-automático]'}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>

        {/* Navigation Buttons - Same style as EvolutionWizard */}
        <div className="flex items-center justify-between gap-2 pt-4 mt-4 border-t border-white/10">
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => {
              if (currentSectionIndex > 0) {
                setActiveSection(sections[currentSectionIndex - 1].id);
              } else {
                onBack();
              }
            }}
            className="text-[11px] h-7"
          >
            Voltar
          </Button>
          
          {currentSectionIndex < sections.length - 1 ? (
            <Button 
              onClick={() => setActiveSection(sections[currentSectionIndex + 1].id)}
              size="sm"
              className="gap-1.5 bg-primary hover:bg-primary/90 text-primary-foreground font-medium h-7 text-[11px]"
            >
              PRÓXIMO
              <ChevronRight className="w-3 h-3" />
            </Button>
          ) : (
            <Button 
              onClick={handleSave}
              disabled={saving}
              size="sm"
              className="gap-1.5 bg-primary hover:bg-primary/90 text-primary-foreground font-medium h-7 text-[11px]"
            >
              {saving ? (
                <Loader2 className="w-3 h-3 animate-spin" />
              ) : (
                <>
                  <Sparkles className="w-3 h-3" />
                  {editingConfig ? 'ATUALIZAR' : 'CRIAR PROJETO'}
                </>
              )}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
