# Genesis Hub - Login & Dashboard (React/TypeScript)

## Conteúdo
- `/src/pages/GenesisIALogin.tsx` - Tela de Login
- `/src/pages/GenesisIADashboard.tsx` - Dashboard principal  
- `/src/pages/GenesisLogin.tsx` - Login alternativo
- `/src/components/genesis-ia/` - Todos os componentes do dashboard
- `/src/components/ui/` - Componentes UI (shadcn)
- `/src/integrations/supabase/` - Cliente e tipos do banco

## Stack
- React 18 + TypeScript
- Vite 5
- Tailwind CSS v3
- Framer Motion
- Recharts
- Supabase (backend)
- shadcn/ui

## Instalação
1. Crie um projeto React + Vite + TypeScript
2. Copie os arquivos para o projeto
3. Instale as dependências: `npm install`
4. Configure o Supabase em `src/integrations/supabase/client.ts`
5. Execute: `npm run dev`
